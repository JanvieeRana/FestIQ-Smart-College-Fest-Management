
package com.college.smartcollegefestmanagement;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class FestController {

    private final FestRepository festRepository;

    public FestController(FestRepository festRepository) {
        this.festRepository = festRepository;
    }

    @GetMapping("/fests")
    public String viewFests(Model model) {
        model.addAttribute("fests", festRepository.findAll());
        return "fests";
    }

    @GetMapping("/fests/new")
    public String showFestForm(Model model) {
        model.addAttribute("fest", new Fest());
        return "fest-form";
    }

    @PostMapping("/fests/save")
    public String saveFest(Fest fest) {
        festRepository.save(fest);
        return "redirect:/fests";
    }
}
