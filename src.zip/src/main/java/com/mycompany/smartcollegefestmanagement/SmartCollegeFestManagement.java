/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.smartcollegefestmanagement;

/**
 *
 * @author Janvi
 */
public class SmartCollegeFestManagement {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
