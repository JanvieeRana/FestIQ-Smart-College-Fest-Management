package com.college.smartcollegefestmanagement;

import com.google.zxing.WriterException;
import java.io.IOException;
import java.util.UUID;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

@Controller
public class ParticipantController {

    private final ParticipantRepository participantRepository;
    private final QrCodeService qrCodeService;

    public ParticipantController(
            ParticipantRepository participantRepository,
            QrCodeService qrCodeService) {
        this.participantRepository = participantRepository;
        this.qrCodeService = qrCodeService;
    }

    // Display participant registration form
    @GetMapping("/participants/register")
    public String showRegistrationForm(Model model) {
        model.addAttribute("participant", new Participant());
        return "participant-form";
    }

    // Save participant and generate QR code
    @PostMapping("/participants/register")
    public String registerParticipant(
            @ModelAttribute Participant participant,
            Model model) throws WriterException, IOException {

        String registrationCode = UUID.randomUUID().toString();

        participant.setRegistrationCode(registrationCode);

        Participant savedParticipant =
                participantRepository.save(participant);

        String qrCode =
                qrCodeService.generateQRCode(registrationCode);

        model.addAttribute("participant", savedParticipant);
        model.addAttribute("qrCode", qrCode);

        return "participant-confirmation";
    }

    // Display all participant registrations
    @GetMapping("/participants")
    public String listParticipants(Model model) {

        model.addAttribute(
                "participants",
                participantRepository.findAll()
        );

        return "participants";
    }
}