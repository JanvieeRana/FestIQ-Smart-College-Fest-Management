package com.college.smartcollegefestmanagement;

import java.time.LocalDateTime;
import java.util.Optional;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AttendanceController {

    private final ParticipantRepository participantRepository;
    private final AttendanceRepository attendanceRepository;

    public AttendanceController(
            ParticipantRepository participantRepository,
            AttendanceRepository attendanceRepository) {

        this.participantRepository = participantRepository;
        this.attendanceRepository = attendanceRepository;
    }

    @GetMapping("/attendance")
    public String showAttendancePage() {
        return "attendance";
    }

    @PostMapping("/attendance/verify")
    public String verifyParticipant(
            @RequestParam String registrationCode,
            Model model) {

        String code = registrationCode.trim();

        Optional<Participant> result =
                participantRepository.findAll()
                        .stream()
                        .filter(p -> p.getRegistrationCode() != null
                                && p.getRegistrationCode().equals(code))
                        .findFirst();

        if (result.isEmpty()) {
            model.addAttribute(
                    "message",
                    "Invalid registration code. Participant not found."
            );
            model.addAttribute("success", false);
            return "attendance";
        }

        Participant participant = result.get();

        boolean alreadyMarked =
                attendanceRepository.existsByRegistrationCodeAndFestName(
                        participant.getRegistrationCode(),
                        participant.getFestName()
                );

        if (alreadyMarked) {
            model.addAttribute(
                    "message",
                    "Attendance has already been marked for this participant."
            );
            model.addAttribute("success", false);
            return "attendance";
        }

        Attendance attendance = new Attendance();

        attendance.setRegistrationCode(
                participant.getRegistrationCode()
        );

        attendance.setParticipantName(
                participant.getParticipantName()
        );

        attendance.setFestName(
                participant.getFestName()
        );

        attendance.setStatus("PRESENT");
        attendance.setCheckInTime(LocalDateTime.now());

        attendanceRepository.save(attendance);

        model.addAttribute(
                "message",
                "Attendance marked successfully!"
        );

        model.addAttribute("success", true);
        model.addAttribute("participant", participant);
        model.addAttribute("attendance", attendance);

        return "attendance";
    }

    @GetMapping("/attendance/records")
    public String viewAttendanceRecords(Model model) {

        model.addAttribute(
                "attendanceRecords",
                attendanceRepository.findAll()
        );

        return "attendance-records";
    }
}