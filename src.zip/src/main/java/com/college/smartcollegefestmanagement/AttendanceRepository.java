package com.college.smartcollegefestmanagement;

import org.springframework.data.jpa.repository.JpaRepository;

public interface AttendanceRepository
        extends JpaRepository<Attendance, Long> {

    boolean existsByRegistrationCodeAndFestName(
            String registrationCode,
            String festName
    );
}