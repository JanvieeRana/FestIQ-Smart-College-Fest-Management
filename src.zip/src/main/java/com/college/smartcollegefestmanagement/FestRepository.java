package com.college.smartcollegefestmanagement;

import org.springframework.data.jpa.repository.JpaRepository;

public interface FestRepository extends JpaRepository<Fest, Long> {

}
