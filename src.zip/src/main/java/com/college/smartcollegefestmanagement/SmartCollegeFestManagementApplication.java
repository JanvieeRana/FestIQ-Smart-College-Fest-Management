
package com.college.smartcollegefestmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartCollegeFestManagementApplication {

    public static void main(String[] args) {
        SpringApplication.run(SmartCollegeFestManagementApplication.class, args);
    }
}
